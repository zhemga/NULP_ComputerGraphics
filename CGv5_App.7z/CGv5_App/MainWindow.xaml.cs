﻿using CGv5_App.Frames;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CGv5_App
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void SetPage(Page page)
        {
            this.MainFrame.Navigate(page);
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (MainFrame.Content is Fractals)
            {
                var fractalsPage = MainFrame.Content as Fractals;

                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "PNG Image|*.png|JPEG Image|*.jpg|Bitmap Image|*.bmp";
                if (saveFileDialog.ShowDialog() == true)
                {
                    string savePath = saveFileDialog.FileName;
                    var imageToSaave = fractalsPage.image.Source;

                    if (imageToSaave is BitmapSource bitmapSource)
                    {
                        var encoder = new PngBitmapEncoder();
                        encoder.Frames.Add(BitmapFrame.Create(bitmapSource));

                        using (var stream = new FileStream(savePath, FileMode.Create))
                        {
                            encoder.Save(stream);
                        }

                        MessageBox.Show("Image saved successfully.");
                    }
                    else
                    {
                        MessageBox.Show("No image source to save.");
                    }
                }
            }
        }
    }
}
